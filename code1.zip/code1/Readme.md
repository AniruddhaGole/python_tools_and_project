1. first open the root terminal of this folder
2. type command "node ruppeeToDollar.js" and press enter
3. the server will start at port 3000
4. open web browser and search "localhost:3000"
