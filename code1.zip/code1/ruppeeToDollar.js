const express = require("express")
const bodyParser = require("body-parser")

const app = express()
const port = 3000

app.use(express.json())
app.use(express.static("public"))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))
app.set("view engine", "ejs")

app.get("/", (req, res) => {
    res.render("index", { amount: -1 })
})

app.post("/convert", (req, res) => {
    const amount = req.body.amount
    const exchangeRate = 0.014
    const amount_in_usd = amount * exchangeRate

    // res.json({ amount_in_usd })
    res.render("index", { amount: amount_in_usd })
})

app.listen(port, () => {
    console.log(`Server started at port: ${port}`)
})