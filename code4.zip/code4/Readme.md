1. first open the root terminal of this folder
2. type command "node index.js" and press enter
3. the server will start at port 3000
4. open we browser and search "localhost:3000/search?query={your_query}"
5. Put any query you want to search about in place of {your_query}
