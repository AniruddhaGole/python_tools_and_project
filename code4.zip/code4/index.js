const express = require('express');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = 'AIzaSyAMAGF9kEgpq6629XdOeHgl3dL0U0ud1qE';
const SEARCH_ENGINE_ID = "c1f04b22648ed4c85"

app.get('/search', async (req, res) => {
    const query = req.query.query;
    if (!query) {
        return res.status(400).json({ error: 'Query parameter missing' });
    }

    try {
        const response = await axios.get(`https://www.googleapis.com/customsearch/v1?key=${API_KEY}&cx=${SEARCH_ENGINE_ID}&q=${query}`);
        const data = response.data;
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

{/* <script async src="https://cse.google.com/cse.js?cx=c1f04b22648ed4c85">
</script>
<div class="gcse-search"></div> */}