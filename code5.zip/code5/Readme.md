1. first open the root terminal of this folder
2. type command "node index.js" and press enter
3. the server will start at port 3000
4. open we browser and search "localhost:3000"
5. Upload a file then press upload button to upload image
6. enter filename with extension in the input and press download button to download that image if present
