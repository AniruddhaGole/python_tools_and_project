const express = require('express');
const path = require("path")
const bodyParser = require("body-parser")
const app = express();

app.use(express.json());
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))

// Sample data - You can replace this with your own data source
let books = [
    { id: 1, title: 'Book 1', author: 'Author 1' },
    { id: 2, title: 'Book 2', author: 'Author 2' },
    { id: 3, title: 'Book 3', author: 'Author 3' }
];

// GET request to retrieve all books
// app.get('/books', (req, res) => {
//     res.json(books);
// });

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"))
})

// GET request to retrieve a specific book by ID
app.get('/books', (req, res) => {
    const bookId = parseInt(req.query.id);
    if (bookId) {
        const book = books.find(book => book.id === bookId);
        if (book) {
            res.json(book);
        } else {
            res.status(404).json({ error: 'Book not found' });
        }
    } else {
        res.json(books);
    }
});

// POST request to add a new book
app.post('/books', (req, res) => {
    const newBook = req.body;
    if (!newBook.title || !newBook.author) {
        res.status(400).json({ error: 'Missing data' });
    } else {
        newBook.id = books.length + 1;
        books.push(newBook);
        res.status(201).json(newBook);
    }
});

// PUT request to update an existing book
app.post('/update-books', (req, res) => {
    const bookId = parseInt(req.body.id);
    req.body.id = parseInt(req.body.id);
    const bookIndex = books.findIndex(book => book.id === bookId);
    if (bookIndex !== -1) {
        books[bookIndex] = { ...books[bookIndex], ...req.body };
        res.json(books[bookIndex]);
    } else {
        res.status(404).json({ error: 'Book not found' });
    }
});

// DELETE request to delete a book by ID
app.post('/delete-books', (req, res) => {
    const bookId = parseInt(req.body.id);
    const initialLength = books.length;
    books = books.filter(book => book.id !== bookId);
    if (books.length < initialLength) {
        res.json({ message: 'Book deleted' });
    } else {
        res.status(404).json({ error: 'Book not found' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
